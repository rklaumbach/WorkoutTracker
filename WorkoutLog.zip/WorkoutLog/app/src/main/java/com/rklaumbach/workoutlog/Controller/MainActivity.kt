package com.rklaumbach.workoutlog.Controller

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.design.widget.Snackbar
import android.support.v4.view.GravityCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.view.MenuItem
import android.support.v4.widget.DrawerLayout
import android.support.design.widget.NavigationView
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.Toolbar
import android.view.Menu
import androidx.room.Room
import com.rklaumbach.workoutlog.Adapters.LogRecycleAdapter
import com.rklaumbach.workoutlog.Model.LogEntry
import com.rklaumbach.workoutlog.Model.WorkoutEntry
import com.rklaumbach.workoutlog.R
import com.rklaumbach.workoutlog.RoomDatabase.AppDatabase
import com.rklaumbach.workoutlog.RoomDatabase.Log
import com.rklaumbach.workoutlog.RoomDatabase.LogDao
import com.rklaumbach.workoutlog.Utilities.EXTRA_LOG_ENTRY
import kotlinx.android.synthetic.main.content_main.*
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {


    override fun onCreate(savedInstanceState: Bundle?) {
        val boogieWoogie = WorkoutEntry("boogie",1,1,"1.0".toFloat())
        val testWorkouts = mutableListOf(boogieWoogie, boogieWoogie)
        //val log = mutableListOf(LogEntry("today",testWorkouts), LogEntry("today",testWorkouts))

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "log"
        ).build()

        var roomLog = db.logDao().getAll()
        var numLogEntries = roomLog.size
        var entries = updateEntries(roomLog)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        val adapter = LogRecycleAdapter(this,entries) {logEntry ->
            switchToWorkoutActivity(logEntry)
        }
        recyclerView.adapter = adapter

        val layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)

        navView.setNavigationItemSelectedListener(this)

        addNewLogEntry.setOnClickListener {
            var workouts = mutableListOf<WorkoutEntry>()
            var newLogEntry = LogEntry(LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yy")),workouts)
            var roomLogEntry = Log(numLogEntries+1, newLogEntry)
            db.logDao().insertAll(roomLogEntry)
            roomLog = db.logDao().getAll()
            entries = updateEntries(roomLog)
            switchToWorkoutActivity(newLogEntry)
        }
    }

    fun switchToWorkoutActivity(logEntry: LogEntry){
        val workoutActivity = Intent(this, WorkoutActivity::class.java)
        workoutActivity.putExtra(EXTRA_LOG_ENTRY, logEntry)
        startActivity(workoutActivity)
    }

    fun updateEntries(roomLog: List<Log>):List<LogEntry>{
        var entries = mutableListOf<LogEntry>()

        for (i in 1..roomLog.size){
            entries.add(roomLog[i-1].logEntry)
        }
        return entries
    }

    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.nav_home -> {
                // Handle the camera action
            }
            R.id.nav_gallery -> {

            }
            R.id.nav_slideshow -> {

            }
            R.id.nav_tools -> {

            }
            R.id.nav_share -> {

            }
            R.id.nav_send -> {

            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }
}
