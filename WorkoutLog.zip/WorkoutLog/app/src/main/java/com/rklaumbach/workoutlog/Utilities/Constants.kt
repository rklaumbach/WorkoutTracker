package com.rklaumbach.workoutlog.Utilities

const val EXTRA_LOG_ENTRY = "log entry"