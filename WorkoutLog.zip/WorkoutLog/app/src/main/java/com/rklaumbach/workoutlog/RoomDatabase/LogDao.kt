package com.rklaumbach.workoutlog.RoomDatabase

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.rklaumbach.workoutlog.Model.LogEntry

@Dao
interface LogDao {
    @Query("SELECT * FROM log")
    fun getAll(): List<Log>

    @Query("SELECT * FROM log WHERE logId IN (:logIds)")
    fun loadAllByIds(logIds: IntArray): List<Log>

    @Insert
    fun insertAll(vararg entries: Log)

    @Delete
    fun delete(user: Log)
}

