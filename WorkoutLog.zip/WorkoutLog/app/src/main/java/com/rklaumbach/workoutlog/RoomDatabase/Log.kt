package com.rklaumbach.workoutlog.RoomDatabase

import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import com.rklaumbach.workoutlog.Model.LogEntry

data class Log(@PrimaryKey val logId:Int, @ColumnInfo(name = "log_entry") val logEntry :LogEntry)